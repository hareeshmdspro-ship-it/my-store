import { STORE } from "./config";

export default function manifest() {
  return {
    name: STORE.name,
    short_name: STORE.name,
    description: STORE.tagline,
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: STORE.themeColor,
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
  };
}
