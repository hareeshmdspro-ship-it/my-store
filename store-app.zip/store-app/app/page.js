"use client";

import { useEffect, useMemo, useState } from "react";
import { STORE, PRODUCTS } from "./config";

const CATEGORIES = ["All", ...new Set(PRODUCTS.map((p) => p.category))];

export default function Home() {
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState({}); // { productId: qty }
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);

  // Load / save cart in the browser so it survives refreshes
  useEffect(() => {
    try {
      const saved = localStorage.getItem("cart");
      if (saved) setCart(JSON.parse(saved));
    } catch {}
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready) {
      try {
        localStorage.setItem("cart", JSON.stringify(cart));
      } catch {}
    }
  }, [cart, ready]);

  const products = useMemo(
    () =>
      PRODUCTS.filter(
        (p) =>
          (category === "All" || p.category === category) &&
          p.name.toLowerCase().includes(query.trim().toLowerCase())
      ),
    [category, query]
  );

  const change = (id, delta) =>
    setCart((c) => {
      const qty = (c[id] || 0) + delta;
      const next = { ...c };
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });

  const items = PRODUCTS.filter((p) => cart[p.id]);
  const count = items.reduce((n, p) => n + cart[p.id], 0);
  const total = items.reduce((n, p) => n + cart[p.id] * p.price, 0);

  const checkout = () => {
    const lines = items.map(
      (p) => `• ${p.name} (${p.unit}) x ${cart[p.id]} = ${STORE.currency}${p.price * cart[p.id]}`
    );
    const text = `Hello ${STORE.name}, I'd like to order:\n${lines.join("\n")}\n\nTotal: ${STORE.currency}${total}`;
    window.open(`https://wa.me/${STORE.whatsapp}?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <main className="app">
      <header className="header">
        <div>
          <h1>{STORE.name}</h1>
          <p>{STORE.tagline}</p>
        </div>
      </header>

      <div className="search">
        <input
          type="search"
          placeholder="Search products…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <nav className="chips">
        {CATEGORIES.map((c) => (
          <button key={c} className={c === category ? "chip active" : "chip"} onClick={() => setCategory(c)}>
            {c}
          </button>
        ))}
      </nav>

      <section className="grid">
        {products.map((p) => (
          <article key={p.id} className="card">
            <div className="emoji">{p.emoji}</div>
            <h3>{p.name}</h3>
            <span className="unit">{p.unit}</span>
            <div className="row">
              <strong>
                {STORE.currency}
                {p.price}
              </strong>
              {cart[p.id] ? (
                <div className="qty">
                  <button onClick={() => change(p.id, -1)} aria-label="Remove one">−</button>
                  <span>{cart[p.id]}</span>
                  <button onClick={() => change(p.id, 1)} aria-label="Add one">+</button>
                </div>
              ) : (
                <button className="add" onClick={() => change(p.id, 1)}>Add</button>
              )}
            </div>
          </article>
        ))}
        {products.length === 0 && <p className="empty">No products found.</p>}
      </section>

      {count > 0 && (
        <button className="cart-bar" onClick={() => setOpen(true)}>
          <span>{count} item{count > 1 ? "s" : ""}</span>
          <span>View cart · {STORE.currency}{total}</span>
        </button>
      )}

      {open && (
        <div className="sheet-backdrop" onClick={() => setOpen(false)}>
          <div className="sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-head">
              <h2>Your cart</h2>
              <button onClick={() => setOpen(false)} aria-label="Close">✕</button>
            </div>
            {items.length === 0 ? (
              <p className="empty">Your cart is empty.</p>
            ) : (
              <>
                <ul>
                  {items.map((p) => (
                    <li key={p.id}>
                      <span>{p.emoji} {p.name} <small>({p.unit})</small></span>
                      <div className="qty">
                        <button onClick={() => change(p.id, -1)}>−</button>
                        <span>{cart[p.id]}</span>
                        <button onClick={() => change(p.id, 1)}>+</button>
                      </div>
                      <strong>{STORE.currency}{p.price * cart[p.id]}</strong>
                    </li>
                  ))}
                </ul>
                <div className="total">
                  <span>Total</span>
                  <strong>{STORE.currency}{total}</strong>
                </div>
                <button className="checkout" onClick={checkout}>Order on WhatsApp</button>
              </>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
