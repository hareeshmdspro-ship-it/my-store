// Edit this file to customise your store.
export const STORE = {
  name: "Fresh Basket",
  tagline: "Fresh groceries, delivered to your door",
  // WhatsApp number with country code, digits only (orders are sent here)
  whatsapp: "919999999999",
  currency: "₹",
  themeColor: "#16a34a",
};

export const PRODUCTS = [
  { id: 1, name: "Organic Tomatoes", price: 60, unit: "1 kg", emoji: "🍅", category: "Vegetables" },
  { id: 2, name: "Fresh Spinach", price: 30, unit: "250 g", emoji: "🥬", category: "Vegetables" },
  { id: 3, name: "Carrots", price: 50, unit: "1 kg", emoji: "🥕", category: "Vegetables" },
  { id: 4, name: "Bananas", price: 55, unit: "1 dozen", emoji: "🍌", category: "Fruits" },
  { id: 5, name: "Apples", price: 180, unit: "1 kg", emoji: "🍎", category: "Fruits" },
  { id: 6, name: "Mangoes", price: 120, unit: "1 kg", emoji: "🥭", category: "Fruits" },
  { id: 7, name: "Fresh Milk", price: 34, unit: "500 ml", emoji: "🥛", category: "Dairy" },
  { id: 8, name: "Farm Eggs", price: 84, unit: "12 pcs", emoji: "🥚", category: "Dairy" },
  { id: 9, name: "Whole Wheat Bread", price: 45, unit: "400 g", emoji: "🍞", category: "Bakery" },
];
