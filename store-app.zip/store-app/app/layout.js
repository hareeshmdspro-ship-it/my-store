import "./globals.css";
import { STORE } from "./config";

export const metadata = {
  title: `${STORE.name} – ${STORE.tagline}`,
  description: STORE.tagline,
  appleWebApp: { capable: true, title: STORE.name, statusBarStyle: "default" },
  icons: { icon: "/icon-192.png", apple: "/icon-192.png" },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: STORE.themeColor,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
